var day_index = 0 ;
var month_index = 0;
function active(){
    var element = document.getElementById("but1");
    element.classList.add("active");
    var element = document.getElementById("but2");
    element.classList.remove("active");
    if(day_index >= 6){
        day_index = -1 ;
    }
    change_day(++day_index);
}
function active1(){
    var element = document.getElementById("but2");
    element.classList.add("active");
    var element = document.getElementById("but1");
    element.classList.remove("active");
    if(month_index >= 11){
        month_index = -1;
    }
    change_month(++month_index);
}
function change_day(a){
    
    var days_of_week = [ "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday" ] ;
    var day = document.getElementById("day");
    day.innerHTML = days_of_week[a] ;  
}
function change_month(b){
    var month = ["January", "February", "March", "April",
     "May", "June", "July", "August", "September", "October", "November", "December" ];
    var months = document.getElementById("monthss");
    months.innerHTML = month[b];
}
function change_text(){
    var msg = document.getElementById("title");
    var add = msg.innerHTML;
    msg.innerHTML = add + " Hello,";
}

/////////////////////////////////image ecercise code////////////////////////////
var slideIndex = 1;
showDivs(slideIndex);

function show_next_picture(n) {
  showDivs(slideIndex += n);
}
function show_previous_picture(n) {
    showDivs(slideIndex += n);
  }
  

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
  var captions = [ "Paris", "Market", "Golden Temple", "USA ",
    "Archor's", "communism", "Wars", "Gateway of India" ] ;
    var cap = document.getElementById("caption");
    cap.innerHTML = captions[slideIndex-1] ;  
}
////////////////////////////////////width--shrink----enlarge code////////////
var slideIndexWidth = 1;
showDivsWidth(slideIndexWidth);

function decreaseWidth(n) {
    showDivsWidthDecrease(slideIndexWidth += n);
}
function increaseWidth(n) {
    showDivsWidthIncrease(slideIndexWidth += n);
  
  }
  

function showDivsWidthIncrease(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndexWidth = 1}
  if (n < 1) {slideIndexWidth = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndexWidth-1].style.display = "block";  
  var wid = parseInt(x[slideIndexWidth-1].style.width);
  var data = wid + 100;  
  x[slideIndexWidth-1].style.width = data  +"px";
  //alert(wid);
}
function showDivsWidthDecrease(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    if (n > x.length) {slideIndexWidth = 1}
    if (n < 1) {slideIndexWidth = x.length}
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    x[slideIndexWidth-1].style.display = "block";  
    var wid = parseInt(x[slideIndexWidth-1].style.width);
    var data = wid - 100;  
    x[slideIndexWidth-1].style.width = data + "px";
    //alert(wid);
  }
  ////////////////add text for images/////////////
  var image_text = 0 ;

function image_text(){
    var element = document.getElementById("caption");
    element.classList.add("active");
    var element = document.getElementById("but2");
    element.classList.remove("active");
    if(day_index >= 7){
        day_index = -1 ;
    }
    change_text_img(++day_index);
}

function change_text_img(a){
    
    var days_of_week = [ "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday" ] ;
    var day = document.getElementById("day");
    day.innerHTML = days_of_week[a] ;  
}